<?php

/**
 * @author blog.anchen8.net
 * @copyright 2014
 */
return array(
    "user_info"=>array("middle"=>array(
        "fields"=>array("name","value"),
        "content"=>"<div>{list}</div>",
        "item"=>"<div class='middle_item' id='middle_item_{index}'>{name}:{value}</div>"
    )),
    "all_users"=>array("middle"=>array(
        "fields"=>array("name","operations"),
        "content"=>"<div>{list}</div>",
        "item"=>"
        	<div class='middle_item' id='middle_item_{index}'>
        		<div class='user_name'>{name}</div>
        		<div class='user_operations'>
                    {operations}
        		</div>
        	</div>
        ",
        "operations_fields"=>array("class","text"),
        "operations_item"=>"<div class='{class} user_operation operation'>{text}</div>"
    )),
    "all_rooms"=>array("middle"=>array(
        "fields"=>array("name","operations"),
        "content"=>"<div>{list}</div>",
        "item"=>"
        	<div class='middle_item' id='middle_item_{index}'>
        		<div class='room_name'>{name}</div>
        		<div class='room_operations'>
                    {operations}
        		</div>
        	</div>
        ",
        "operations_fields"=>array("class","text"),
        "operations_item"=>"<div class='{class} room_operation  operation'>{text}</div>"
    )),
    "friends_request"=>array("middle"=>array(
        "fields"=>array("who_name","operations"),
        "content"=>"<div>{list}</div>",
        "item"=>"
        	<div class='middle_item' id='middle_item_{index}'>
        		<div class='friend_request_text'><span class='friend_request_name'>{who_name}</span>请求加为好友</div>
        		<div class='friend_request_operations'>
                    {operations}
        		</div>
        	</div>
        ",
        "operations_fields"=>array("class","text"),
        "operations_item"=>"<div class='{class} friend_request_operation operation'>{text}</div>"
    )),
    "rooms_request"=>array("middle"=>array(
        "fields"=>array("who_name","room_name","operations"),
        "content"=>"<div>{list}</div>",
        "item"=>"
        	<div class='middle_item' id='middle_item_{index}'>
        		<div class='room_request_text'><span class='room_request_who'>{who_name}</span>请求加入聊天室<span class='room_request_room'>{room_name}</span></div>
                <div class='room_request_operations'>
                    {operations}
        		</div>
        	</div>
        ",
        "operations_fields"=>array("class","text"),
        "operations_item"=>"<div class='{class} room_request_operation operation'>{text}</div>"
    )),
    "friend_chat"=>array("middle"=>array(
        "fields"=>array("receive_or_send","name","time","message","send_clear"),
        "content"=>"
            <div>
        		<div id='message_table'>{list}</div>
        		<div  id='message_operations'>
        			<a id='message_operation_lookup_messages' target='_blank' href=''>聊天记录</a>
        		</div>
        		<div  id='message_edit'>
        			<textarea id='message_edit_text' rows='auto'></textarea>
        			<div id='message_edit_send'>发送</div>
        		</div>
            </div>
        ",
        "item"=>"
            <div class='message_{receive_or_send}'>
				<div class='message_{receive_or_send}_head'>
				    <div class='message_{receive_or_send}_head_name'>{name}</div>
				    <div class='message_{receive_or_send}_head_time'>({time})</div>
                </div>{send_clear}
                <div class='message_body message_{receive_or_send}_body'>{message}</div>
            </div>
        "
    ),"right"=>array(
        "fields"=>array('value','name'),
        "content"=>"<div>{list}</div>",
        "item"=>"
            <div class='content_right_item' id='content_right_item_{index}'>
            　{name}:<br/>
		      {value}
            </div>
        "
    )),
    "room_chat"=>array("middle"=>array(
        "fields"=>array("receive_or_send","name","time","message","send_clear"),
        "content"=>"
            <div>
        		<div id='message_table'>{list}</div>
        		<div  id='message_operations'>
        			<a id='message_operation_lookup_messages' target='_blank' href=''>聊天记录</a>
        			<div id='message_operation_only_friends'>
        				<input id='only_friends' name='only_friends' type='checkbox' onChange='alert(&quot;待实现...&quot;);' value='' checked  />
        				<label for='only_friends'>只显示好友消息</label>
        			</div>
        	
        		</div>
        		<div  id='message_edit'>
        			<textarea id='message_edit_text' rows='auto'></textarea>
        			<div id='message_edit_send'>发送</div>
        		</div>
            </div>
        ",
        "item"=>"
            <div class='message_{receive_or_send}'>
				<div class='message_{receive_or_send}_head'>
				    <div class='message_{receive_or_send}_head_name'>{name}</div>
				    <div class='message_{receive_or_send}_head_time'>({time})</div>
                </div>{send_clear}
                <div class='message_body message_{receive_or_send}_body'>{message}</div>
            </div>
        "
    ),"right"=>array(
        "fields"=>array("name","operations"),
        "content"=>"<div>{list}</div>",
        "item"=>"
        	<div class='right_item' id='right_item_{index}'>
        		<div class='user_name'>{name}</div>
        		<div class='user_operations'>
                    {operations}
        		</div>
        	</div>
        ",
        "operations_fields"=>array("class","text"),
        "operations_item"=>"<div class='{class} user_operation operation'>{text}</div>"
    ))
    
);


?>