﻿/**
 * 设置中间标头
 */
 function smh(h){
    $("#content_middle_head").text(h);
 }
 /**
 * 设置右边标头
 */
 function srh(h){
    $("#content_right_head").text(h);
 }

 /**
  * 定时任务
  */
 var TimeTask={
    create:function(ms){
        //console.log("create");
        var ret={
            ID:0,
            delay:ms,
            task_queue:{},
            pump:function(){
                //console.log("pump");
                //dump(ret.task_queue);
                for(i in ret.task_queue){
                    var fun=ret.task_queue[i].fun;
                    var count=parseInt(ret.task_queue[i]["count"]);
                    //执行函数
                    try{
                        fun.call(window);
                    }catch(e){
                        count=1;
                        //console.log("定时任务"+i+"执行错误!");
                    }
                    /*
                    if(--count==0)
                        delete ret.task_queue[i];
                    else{
                        ret.task_queue[i]["count"]=""+count;
                    }
                    console.log("count"+count);
                    */
                }
                ret.start();
                
            },
            start:function(){
                //console.log("start");
                ret.end();
                clearTimeout(ret.ID);
                ret.ID=setTimeout(ret.pump,ret.delay);
            },
            end:function(){
                //console.log("end");
                clearTimeout(ret.ID);
                ret.ID=0;
            },
            add_task:function(name,task_info){
                //console.log("add_task");
                ret.task_queue[name]=task_info;
            },
            exec:function(t){
                //console.log("exec");
                ret.end(ret.ID);
                ret.ID=setTimeout(ret.pump,t);
            }
        }
        return ret;
    }
 }
 is_ajax_waiting=false;
/**
 * 设置中间内容
 */
  function smc(c){
    if(data.curr_category!="room_chat" && data.curr_category!="friend_chat"){
        $("#content_middle_content").html($(c).html());      
        switch_odd_even(".middle_item");
    }else{
        //如果是聊天界面,jQuery不能生成设计的html代码,需要特殊处理
        var s=c.indexOf(">")+1;
        var e=c.lastIndexOf("<")-1;
        var c=c.substr(s,e-s+1);
        $("#content_middle_content").html(c);
        //聊天记录查看url
        $("#message_operation_lookup_messages").attr("href",data[data.curr_category].message_list);
        //消息发送
        var t=data.__client__.t;
        t.add_task("recv_or_send_messages",{
            fun:function(){
                //console.log("回调");
                if(is_ajax_waiting)return;
                //console.log("消息处理函数开始了!");
                is_ajax_waiting=true;
                var url=data[data.curr_category].message_send.url;
                var _data=data[data.curr_category].message_send.params;
                _data.msg=data.__client__.m;
                //console.log(_data.msg);
                data.__client__.m=[];
                //console.log(url);
                //console.log(_data);
                 rp(url,_data)
                .done(function(d){
                    if(d.status=="sucess"){
                        //tip("成功处理消息");
                        //console.log(d);
                        var tip_msg="";
                        if(_data.msg.length>0)tip_msg="消息发送成功";
                        if(d.messages.length>0){
                            for(i=0;i<d.messages.length;i++){
                                //data.__client__.t.end();
                                //console.log(d.messages.length);
                                data[d.dest_category].middle.list[data[d.dest_category].middle.list.length]=d.messages.list[i];
                            }
                            if(tip_msg=="")tip_msg+="更新"+d.messages.length+"条消息";
                            else tip_msg+=",更新"+d.messages.length+"条消息";
                            old=$.trim($("#message_edit_text").val());
                            generate_content(d.dest_category,data[d.dest_category]);
                            //$("#message_edit_text").focus();
                            setTimeout(function(){
                                $("#message_edit_text").focus();
                                $("#message_edit_text").val(old);},500);
                            data[data.curr_category].message_send.params=d.params;
                        }
                        if(tip_msg=="")tip_msg="后台5秒进行一次消息查询,您尚未收到新消息...";
                        tip(tip_msg);
                        //generate_content(d.dest_category,d[d.dest_category]);
                    }
                    else tip("消息处理失败!");
                    })
                .fail(function(e){
                    tip("消息处理Ajax失败!");
                    //console.log("消息处理Ajax失败!");
                    //alert(e["responseText"]);
                    //console.log(e);
                    })
                .always(function(){
                    is_ajax_waiting=false;
                    //console.log("回调结束!");
                });
                },
            count:"-1",
        });
        t.start();                                      //启动定时器
        $("#message_edit_send").css("cursor","pointer");
        $("#message_edit_send").click(function(){
            var msg=$("#message_edit_text").val();
            $("#message_edit_text").val("");
            if(msg==false){
                alert("对不起,您需要输入消息内容才可以发送");
                return;
            }
            //将消息插入队例
            data.__client__.m[data.__client__.m.length]=msg;
            tip("["+msg+"]消息已经进入消息列队,正在等待发送,请稍候...");
            //console.log(data.__client__.m);
            //立即触发定时器
            t.exec(500);
        });
        //h=parseInt($("#message_table").css("height"));
        $("#message_table").scrollTop("99999");
        $("#message_edit_text").keydown(function(){
            if(event.keyCode==13){
                $("#message_edit_send").click();
                return false;
            }
        });
        //console.log("return");
    }
 }
/**
 * 设置右边内容
 */
  function src(c){
    $("#content_right_content").html($(c).html());
    switch_odd_even(".right_item");
 }
 /**
  * 切换奇偶类
  */
 function switch_odd_even(selector){
    $(selector+":nth-child(odd)").removeClass("even");
    $(selector+":nth-child(even)").removeClass("odd");
    $(selector+":nth-child(odd)").addClass("odd");
    $(selector+":nth-child(even)").addClass("even");
 }
 
 /**
  * 设置提示信息
  */
 function tip(msg){
    $("#tip").text(msg);    
 }
 /**
  * 显示对象
  */
 function dump(o){
    var temp="";
    for(i in o){
        temp=temp+i+":"+o[i]+"\n";
    }
    tip(temp);
 }

 /**
  * 默认的get ajax request对象
  */
  function rg(_url,_data){
    if(_data==undefined)_data={};
    _data["u"]=data.user.id;
    return $.ajax({
        url: _url,
        type:"GET",
        data: _data,
        dataType: "json",
        beforeSend:function(jqXHR,settings){
            return true;
            }
        });
  }
 /**
  * 默认的get ajax request对象
  * ("Manager/reset")
  * ("Manager","reset")
  * ("Manager/reset",data)
  * ("Manager","reset",data)
  */
  function rp(m,a,_data){
    var ta;
    if(m.indexOf("/")!=-1){
        _data=a;
        ta=m.split("/");
        m=ta[0];
        a=ta[1];
    }
    if(_data==undefined)_data={};
    url=data.APP+"/"+m+"/"+a;
    //_data["a"]=a;
    //_data["m"]=m;
    //url=data.APP;
    if(_data["u"]==undefined)_data["u"]=data.user.id;
    return $.ajax({
        url: url,
        type:"POST",
        data: _data,
        dataType: "json",
        beforeSend:function(jqXHR,settings){
            return true;
            }
        });
  }
 /**
  * 创建房间
  */
  function create_room(){
    var room_name=$("#room_name").val();
    if($.trim(room_name)==""){
        tip("请输入要创建的聊天室名字,然后创建...");
        return;
    }
    tip("正在请求创建聊天室["+room_name+"]请稍候...");
    rp("Manager/room_create",{r:room_name})
    .done(function(d){
        if(d.status=="sucess"){
            tip("成功创建聊天室"+room_name);
            generate_content(d.dest_category,d[d.dest_category]);
        } 
        else tip("创建聊天室失败!");
        })
    .fail(function(e){
        tip("创建聊天室AJAX请求失败!");
        });
  }
  /**
  * 重置系统
  */
  function reset_system(){
    //reset_url=data.APP+"/Manager/system_reset";
    //rg(reset_url).done(function(m){alert("sucess");}).fail(function(e){alert("fail");});
    rp("Manager/system_reset")
    .done(function(d){
        if(d.status=="sucess") tip("重置数据库成功");
        else tip("重置数据库失败!");
        })
    .fail(function(e){
        tip("重置数据库AJAX请求失败!");
        });
  }
  /**
  * 从id得到索引
  */
  function get_item_index(id){
    var a=id.split("_");
    return a[a.length-1]-1;
  }
   /**
   * 生成分类内容
   */
  function generate_content_item_operations(operations,fields,item,operations_data){
    var ret="";
    for(i in operations){
        temp=item;
        operation_class=operations[i];
        for(j in fields){
            f=fields[j];
            if(f=="class")temp=temp.replace(new RegExp("\\{class\\}","g"),operation_class);
            else temp=temp.replace(new RegExp("\\{"+f+"\\}","g"),operations_data[operation_class][f]);
        }
        ret+=temp;
    }
    return ret;
  }
   /**
   * 生成分类内容
   */
  function generate_content_item(item_data,fields,item,d,tag){
    var ret=item;
    for(i in fields){
        f=fields[i];
        if($.isArray(item_data[f])){
            ret=ret.replace(new RegExp("\\{"+f+"\\}","g"),generate_content_item_operations(item_data[f],tag[f+"_fields"],tag[f+"_item"],d[f]));
        }else{
            ret=ret.replace(new RegExp("\\{"+f+"\\}","g"),item_data[f]);
        }
    }
    return ret;
  }
  /**
   * 生成分类内容
   */
  function generate_content_list(d,tag){
    var fields=tag.fields;
    var content=tag.content;
    //dump(item);
    //alert(item);
    var item=tag.item;
    var list=d.list;
    var l="";
    for(i in list){
        _item=item.replace(new RegExp("\\{index\\}","g"),""+i);
        l+=generate_content_item(list[i],fields,_item,d,tag);
    }
    content=content.replace(/\{list\}/g,l);
    return content;

  }
  /**
   * 生成分类内容
   */
  function generate_content(category,content){
    //先清空数据
    $("#content_middle_content").html("");
    $("#content_right_content").html("");
    smh("");
    srh("");
    //设置当前分类
    data.curr_category=category;
    //更新分类数据
    data[category]=content;
    middle=content["middle"];
    right=content["right"];
    middle_tag=data.tags[category].middle;
    right_tag=data.tags[category].right;

    //middle
    if(middle!=undefined){
        smh(middle.head);
        smc(generate_content_list(middle,middle_tag));
    }
  
    //right
    if(right!=undefined){
        srh(right.head);
        src(generate_content_list(right,right_tag));
    }
    //切换css
    $("#css").attr("href",data.cssdir+category+".css");
    //处理按钮
    $(".operation").click(function(){
        data.__client__.t.end();
        var operation;
        operation=get_operation(this,data[category].middle.operations);
        if(operation==false){
            if(data[category].right!=false){
                operation=get_operation(this,data[category].right.operations);
                if(operation==false)return;
            }
        }
        _item=get_index(this);
        _id=_item.id;
        var _data;
        if(operation["params"]!=undefined)_data=operation["params"];
        else _data={};
        _data.id=_id;
        tip("正在请求"+operation["text"]+"请稍候...");
        rp(operation["url"],_data)
        .done(function(d){
            if(d.status=="sucess"){
                if(operation["url"]=="User/room_request")tip(operation["text"]+"成功,等待管理员审核...");
                else if(operation["url"]=="User/friend_request")tip(operation["text"]+"成功,等待对方审核...");
                else tip(operation["text"]+"成功");
                //dump(d);
                generate_content(d.dest_category,d[d.dest_category]);
            }
            else tip(operation["text"]+"失败!");
            })
        .fail(function(e){
            tip(operation["text"]+"AJAX失败!");
            });
    });
    
    $(".operation").mouseover(function(elem){
        $(this).css("cursor","pointer");
    }).mousedown(function(){
        
    }).mouseup(function(){
        
    }).mouseout(function(){
        
    });
    
    $(".menu_item").mouseover(function(elem){

    }).mousedown(function(){
        
    }).mouseup(function(){
        
    }).mouseout(function(){
        
    });
  }
  /**
   * 获取当前点击按钮的操作数据
   */
  function get_operation(_b,operations){
    if(operations==false)return false;
    var b=$(_b);
    for(i in operations){
        operation=operations[i];
        if(b.hasClass(i)){
            return operation;
        }
    }
    return false;
  }
  /**
   * 获取当前按钮的索引
   */
  function get_index(_b){
    try{
        var c=$(_b);
        while(!c.hasClass("middle_item") && !c.hasClass("right_item")){
            c=c.parent();
        }
        var a=c.attr("id").split("_");
        var index=parseInt(a[a.length-1]);
        if(c.hasClass("middle_item"))return data[data.curr_category].middle.list[index];
        return data[data.curr_category].right.list[index];
    }catch(e){return false;}
  }
  /**
  * 菜单处理
  */
  function on_menu_click(_menu){
     data.__client__.t.end();
     var i=get_item_index($(_menu).attr("id"));
     var m=data.menu[i];
     tip("正在请求"+m.name+"请稍候...");
     rp(m.url)
    .done(function(d){
        if(d.status=="sucess"){
            tip("当前>>"+m.name);
            generate_content(d.dest_category,d[d.dest_category]);
        }
        else{ 
            tip("切换至"+m.name+"失败!");
        }
        
        })
    .fail(function(e){
        //console.log(e);
        tip("切换至"+m.name+"AJAX失败!");
        });
  }
  
$(function(){
    //初始化按钮
    data.__client__={};
    data.__client__.m=[];                                        //要发送的消息
    data.__client__.t=TimeTask.create(5000);                        //初始化延时任务
    });