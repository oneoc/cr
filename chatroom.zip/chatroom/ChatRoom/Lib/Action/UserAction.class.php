<?php
// 本类由系统自动生成，仅供测试用途
class UserAction extends BaseAction {
    /**
     * 用户登录
     * @param 用户名
     * @param 密码
     */
    function login($name,$psw){
        $user=D("User")->get_user($name);
        if($user!=null){
            if($user->login($psw)) $this->redirect("User/welcome?u=".$user->id);
        }
        $this->msg="您请求的用户不存在,或者密码错误,请重新输入!";
        $this->display("Index:login"); 
    }
    /**
     * 用户注册
     * @param 用户名
     * @param 密码
     * @param 邮箱
     */
    function register($name,$psw,$mail){
        //dump(get_defined_constants());
        if(D("User")->get_user($name)!==null){
            $this->msg="此用户名已经被占用,请重新选择!";
            $this->display("Index:register");
            return;
        }
        $user=D("User")->add_user($name,$psw,$mail);
        $user=D("User");
        $user->get_user($name);
        if($user!=null)
        {
            $user->login($psw);
            $this->redirect("User/welcome?u=".$user->id."&new=true");
        }
        $this->msg="注册时发生错误,请稍候重试!";
        $this->display("Index:register");     
    }
    /**
     * 欢迎界面,主页
     * @param 自己
     */
    function welcome($u){
        //json数据
        $data=array();
        $data["status"]="sucess";
        $this->user_info=$data["user_info"]=$this->user->get_show_user_info();
        if($this->isAjax()){
            $data["dest_category"]="user_info";
            $GLOBALS["ajax_data"]=$data;
            return;
        }
        if(isset($_GET["new"]) && $_GET["new"]=="true"){
            $this->assign("tip","恭喜您,您已经成功注册,请到默认聊天室聊天,或者添加好友,申请其他聊天室.");}
        else{
            $this->assign("tip","谢谢使用!您的支持就是我前进的最大动力.");}
        $data["cssdir"]=__ROOT__."/ChatRoom/Tpl/User/";
        $data["curr_category"]="user_info";
        $data["APP"]=__APP__;
        //用户
        $data["user"]=D("User")->find($this->user->id);
        //左侧菜单
        $menu=array(
            array("name"=>"用户信息","url"=>"User/welcome"),
            array("name"=>"所有用户","url"=>"User/user_lookup"),
            array("name"=>"所有聊天室","url"=>"User/room_lookup"),
            array("name"=>"好友请求","url"=>"User/request_friends_status"),
            );
        $menu_manager=array();
        if($this->user->is_manager()){
            $menu_manager[]=array("name"=>"聊天室请求","url"=>"Manager/request_rooms_status");
            $this->create_room_tag='
                        <div>
                        	  <input id="room_name" name="room_name" type="text"/>
                        	  <input id="create_room" type="submit" value="创建聊天室" onclick="create_room()"/>
                        </div>
                    ';
        }
        $data["tags"]=require TMPL_PATH."User/content_tags.php";
        $menu=array_merge($menu,$menu_manager);
        $this->menu=$menu;
        $data["menu"]=$menu;
        $data_js=json_encode($data);
        //$data_js=str_replace('"',"\\\"",$data_js);
        $data_js=str_replace("'","\\\"",$data_js);
        $this->data=$data_js;
        $this->assign("user",$data["user"]);
        //dump($data);
        $this->display();
    }
    /**
     * 好友请求
     * @param 自己
     * @param 请求者
     */
    function friend_request($u,$id){
        $this->user->request_friend($id);
        $this->user_lookup($u);
    }
    /**
     * 房间请求
     * @param 自己
     * @param 房间
     */
    function room_request($u,$id){
        $this->user->request_room($id);
        $this->room_lookup($u);
    }
    /**
     * 好友删除
     * @param 自己
     * @param 删除者
     */
    function friend_delete($u,$id){
        D("User")->delete_friend($u,$id);
        D("User")->delete_friend($id,$u);
        $this->user_lookup($u);
    }
    /**
     * 退出房间
     * @param 自己
     * @param 房间
     */
    function room_exit($u,$id){
        $r=D("Room");
        $r->find($id);
        $r->delete_user($u);
        $this->room_lookup($u);
    }
    /**
     * 进入房间聊天
     * @param 自己
     * @param 房间
     *
     */
    function room_chat($u,$id){
        $r=D("Room");
        $r->find($id);
        if($r!=false){
            $data["status"]="sucess";
            $data["dest_category"]="room_chat";
            $data["room_chat"]=$this->user->get_show_room_chat($id,"聊天室(".$r->name.")");
            $GLOBALS["ajax_data"]=$data;
            //dump($data);            
        }
    }
    /**
     * 查看用户列表
     * @param 自己
     */
    function user_lookup($u){
        $data["status"]="sucess";
        $data["dest_category"]="all_users";
        $data["all_users"]=$this->user->get_show_all_users("所有用户");
        $GLOBALS["ajax_data"]=$data;
        //dump($data);
    }
    /**
     * 处理好友请求
     * @param 自己
     * @param 请求者
     * @param 动作 默认同意
     */
    function friend_request_process($u,$id,$act=UserModel::ACTION_AGREE){
        $this->user->friend_request_process($id,$act);
        $this->request_friends_status($u);        
    }
    /**
     * 退出登录
     * @param 自己
     */
    function quit($u){
        if($this->user!=null){
            $this->user->quit();
        }
        $this->redirect("Index/index");
    }
    /**
     * 私聊
     * @param 自己
     * @param 朋友
     */
    function friend_chat($u,$id){
        $f=D("User")->find($id);
        if($f!=false){
            D("User")->find($u);
            $data["status"]="sucess";
            $data["dest_category"]="friend_chat";
            $data["friend_chat"]=$this->user->get_show_friend_chat($id,"朋友(".$f["name"].")");
            $GLOBALS["ajax_data"]=$data;
            //dump($data);            
        }
    }
    /**
     *返回较大的日期
     */
    private function get_bigger_date($d1,$d2){
        return $d1;
    }
    /**
     * 发送并且返回消息
     * @param 自己
     * @param 朋友
     * @param 消息
     * @param 最后一条消息的时间
     */
    function message_friend($u,$f){
        $latest=$_REQUEST["latest"];
        $friend=D("User")->find($f);
        if($friend==false){
            $GLOBALS["ajax_data"]=array("status"=>"fail");
            return;
        }
        D("User")->find($u);
        if(isset($_REQUEST["msg"]))$this->user->send_message_friend($friend,$_REQUEST["msg"]);
        $data=$this->user->get_messages_since($friend,$latest);
        if(sizeof($data)>0)$latest=$data[sizeof($data)-1]["time"];
        $messages_list=array();
        foreach($data as $d){
            $messages_list[]=array("send_clear"=>$d["type"]==UserModel::MESSAGE_TYPE_SEND?"<div class='clear'></div>":"","receive_or_send"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?"receive":"send","name"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?$d["user_name"]:"我","time"=>$d["time"],"message"=>$d["message"]);
        }
        $data=array();
        $data["status"]="sucess";
        $data["dest_category"]="friend_chat";
        $data["params"]=array("f"=>$f,"latest"=>$latest);
        $data["messages"]=array("length"=>sizeof($messages_list),"list"=>$messages_list);
        $GLOBALS["ajax_data"]=$data;
        //dump($data);

    }
    /**
     * 发送并且返回消息
     * @param 自己
     * @param 房间
     * @param 消息
     * @param 最后一条消息的时间
     */
    function message_room($u,$r){
        $latest=$_REQUEST["latest"];
        $room=D("Room");
        $room->find($r);
        if(isset($_REQUEST["msg"]))$this->user->send_message_room($room,$_REQUEST["msg"]);
        $data=$this->user->get_messages_since_room($room,$latest);
        if(sizeof($data)>0)$latest=$data[sizeof($data)-1]["time"];
        $messages_list=array();
        foreach($data as $d){
            $messages_list[]=array("send_clear"=>$d["type"]==UserModel::MESSAGE_TYPE_SEND?"<div class='clear'></div>":"","receive_or_send"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?"receive":"send","name"=>$d["user_name"],"time"=>$d["time"],"message"=>$d["message"]);
        }
        $data=array();
        $data["status"]="sucess";
        $data["dest_category"]="room_chat";
        $data["params"]=array("r"=>$r,"latest"=>$latest);
        $data["messages"]=array("length"=>sizeof($messages_list),"list"=>$messages_list);
        $GLOBALS["ajax_data"]=$data;
        //dump($messages_list);
        //$this->display("Index:index");
    }
    /**
     * 发送消息
     * @param 自己
     * @param 朋友
     * @param 消息
     */
    function send_message_friend($u,$f,$m){}
    /**
     * 查询房间消息
     * @param 自己
     * @param 房间
     * @param 时间
     * @param 消息数
     */
    function query_message_room($u,$r,$t,$c){}
    /**
     * 查询好友消息
     * @param 自己
     * @param 好友
     * @param 时间
     * @param 消息数
     */
    function query_message_friend($u,$f,$t,$c){}
    /**
     * 房间列表
     * @param 自己
     */
    function room_lookup($u){
        $data["status"]="sucess";
        $data["dest_category"]="all_rooms";
        $data["all_rooms"]=$this->user->get_show_all_rooms("所有聊天室");
        $GLOBALS["ajax_data"]=$data;
        //dump($data);
    }
    /**
     * 发送群聊消息
     * @param 自己
     * @param 房间
     * @param 消息
     */
    function send_message_room($u,$r,$m){}
    /**
     * 好友请求状态,只返回请求未处理的好友
     * @param 自己
     */
    function request_friends_status($u){
        $data["status"]="sucess";
        $data["dest_category"]="friends_request";
        $data["friends_request"]=$this->user->get_show_friends_request("所有待处理的好友请求");
        $GLOBALS["ajax_data"]=$data;
        //dump($data);
    }
    /**
     * 好友消息列表
     * @param 自己
     * @param 朋友
     */
    function messages_list_friend($u,$f){
        $_f=D("User")->find($f);
        D("User")->find($u);
        if($_f==false){
            $this->title="该用户不存在";
            $messages=array();
        }else{
            $this->title="与".$_f["name"]."的聊天记录";
            $this->messages=$this->user->get_messages_latest($f);  
        }
        $this->assign("MESSAGE_TYPE_RECV",UserModel::MESSAGE_TYPE_RECV);
        $this->assign("MESSAGE_TYPE_SEND",UserModel::MESSAGE_TYPE_SEND);
        $this->display("Public:messages_list");
    }
    /**
     * 房间消息列表
     * @param 自己
     * @param 朋友
     */
    function messages_list_room($u,$r){
        $_r=D("Room");
        if($_r->find($r)==false){
            $this->title="该聊天室不存在";
            $this->messages=array();
        }
        else {
            $this->title=$_r->name."的聊天记录";
            $this->messages=$this->user->get_messages_latest_room($_r);
        }
        $this->assign("MESSAGE_TYPE_RECV",UserModel::MESSAGE_TYPE_RECV);
        $this->assign("MESSAGE_TYPE_SEND",UserModel::MESSAGE_TYPE_SEND);
        $this->display("Public:messages_list");
    }
}