<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends BaseAction {
    /**
     * 网站入口,安装(Index/index)或者登录(Index/login)
     */
    public function index()
    {
        $db=new Database();
        if(!$db->isInitialized())
        {
            $this->display();
            return;
        }
        $this->display("login");
    }
    /**
     * 执行安装
     * @param 管理员姓名
     * @param 密码
     * @param 邮箱
     */
    public function setup($name,$psw,$mail,$DB_HOST,$DB_NAME,$DB_USER,$DB_PWD)
    {
        $db=new Database();
        if($db->isInitialized()){
            $this->display("Index:login");
            return;
        }
        $db_init=Database::config($DB_HOST,$DB_NAME,$DB_USER,$DB_PWD);
        if($db_init===true){
            if($db->execute_init())
            {
                D("User")->add_user($name,$psw,$mail,UserType::MANAGER);
                $user=D("Manager")->get_user($name);
                if($user!=null){
                    $user->login($psw);
                    $this->redirect("User/welcome?u=".$user->id."&new=true");
                }
            }else{
                $this->msg="数据库初始化失败,请确定指定数据库为空!";
            }
        }else{
            $this->msg=$db_init;
        }

        $this->display("Index:index");

    }
    public function register()
    {
        $db=new Database();
        //dump(get_defined_constants());
        if($db->isInitialized()==false)
        {
            $this->display("Index:index");
            return;
        }
        $this->display();
    }
}