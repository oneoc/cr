<?php
// 本类由系统自动生成，仅供测试用途
class BaseAction extends Action {
    /**
     * 当前登录用户模型
     */
    protected $user;
    /**
     * 访问控件对象
     */
    protected $access_control;
    /**
     * 魔术方法 有不存在的操作的时候执行
     * @access public
     * @param string $method 方法名
     * @param array $args 参数
     * @return mixed
     */
    protected function _initialize()
    {
        //dump(U("User/login"));
        //dump(get_defined_constants());
        $user=$this->user=&$this->config["user"];
        $access_control=$this->access_control=&$this->config["access_control"];
        //View变量,当前模板路径
        $this->assign('MODULE_NAME',MODULE_NAME);
        $this->assign('ACTION_NAME',ACTION_NAME);
        $GLOBALS["isAjax"]=$this->isAjax();
        $GLOBALS["ajax_data"]=array("status"=>"fail");
        //Index/index,User/register,Index/setup将自动通过
        if(!(MODULE_NAME=="Index" && (ACTION_NAME=="index" || ACTION_NAME=="setup" || ACTION_NAME=="register")) && !(MODULE_NAME=="User" && (ACTION_NAME=="login" || ACTION_NAME=="register")))
        {
            //用户为空或者未登录,则跳入登录界面
            if($user==false || !$user->is_login())
            {
                if($this->isAjax())
                {
                    $this->ajaxReturn($GLOBALS["ajax_data"],"json");
                    return;
                }else{
                    $this->assign('CURR_TMPL_PATH',APP_PATH."Tpl/"."Index");
                    $this->redirect("Index/index",array(),$delay=3,$msg='yuo need login,you will go to the login page...');
                    return; 
                }

            }
            //检查用户权限,非Index/index,Index/setup,User/register
            if(!$user->has_priority(ACTION_NAME,$access_control))
            {

                if($this->isAjax())
                {
                    $this->ajaxReturn($GLOBALS["ajax_data"],"json");
                    return;
                }
                else
                {
                    $this->assign('CURR_TMPL_PATH',APP_PATH."Tpl/"."Welcome");
                    $this->redirect("User/welcome?u=".$user->data["id"],array(),$delay=3,$msg='you have not priority to request for this url,you will go to the welcome page');
                    return;
                }
            }
        }
    }
    public function __call($method,$args) {
        $this->redirect("Index/index",array(),$delay=3,$msg='The request is not exist,you will jump to the login page');
        }
}