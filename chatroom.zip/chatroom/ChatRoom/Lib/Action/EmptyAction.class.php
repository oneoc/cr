<?php
// 本类由系统自动生成，仅供测试用途
class EmptyAction extends Action {
    /**
     * 魔术方法 有不存在的操作的时候执行
     * @access public
     * @param string $method 方法名
     * @param array $args 参数
     * @return mixed
     */
    public function __call($method,$args) {
        //$this->redirect("Index/index",array(),$delay=3,$msg='The request is not exist,you will jmup to the login page');
        }
}