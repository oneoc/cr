<?php
// 本类由系统自动生成，仅供测试用途
class ManagerAction extends UserAction {
    /**
     * 重置系统,清空数据库,保留当前管理员,全局数据库
     * @param 当前登录管理员用户
     */
    public function system_reset($u){
        $this->user->system_reset();
        $GLOBALS["ajax_data"]=array("status"=>"sucess");
    }
    /**
     * 删除房间
     * @param 管理员
     * @param 房间
     */
    public function room_delete($u,$id){
        D("Room")->delete_room($id);
        $this->room_lookup($u);
    }
    /**
     * 踢出房间
     * @param 自己
     * @param 房间
     * @param 踢出对象
     */
    function member_delete($u,$r,$id){
        D("RoomUser")->delete($id);
        $this->room_chat($u,$r);
    }
    /**
     * 创建房间
     * @param 管理员
     * @param 房间
     */
    public function room_create($u,$r){
        if($r==""){
            $GLOBALS["ajax_data"]["status"]="fail";
            return;
        }
        if(D("Room")->add_room($r)!=null){
            $data["status"]="sucess";
            $data["dest_category"]="all_rooms";
            $data["all_rooms"]=$this->user->get_show_all_rooms("所有聊天室");
            $GLOBALS["ajax_data"]=$data;
        }else{
            $GLOBALS["ajax_data"]["status"]="sucess";
        }
    }
    /**
     * 房间请求处理
     * @param 管理员
     * @param 请求者
     * @param 房间
     * @param 动作
     */
    public function room_request_process($u,$id,$act=UserModel::ACTION_AGREE){
        D("Room")->room_request_process($id,$act);
        $this->request_rooms_status($u);
    }
    /**
     * 删除用户
     * @param 管理员
     * @param 要删除用户
     */
    public function user_delete($u,$id){
        $this->user->user_delete($id);
        $this->user_lookup($u);
    }
    /**
     * 返回所有的房间请求
     * @param 管理员
     */
    public function request_rooms_status($u){
        //dump(D("RoomMessageView")->select());
        //dump(D("RoomRequestView")->select());
        //dump(D("FriendRequestView")->select());
        //$this->display("Index:index");
        //return;
        $data["status"]="sucess";
        $data["dest_category"]="rooms_request";
        $data["rooms_request"]=$this->user->get_show_rooms_request("所有待处理的房间加入请求");
        $GLOBALS["ajax_data"]=$data;
        //dump($data);
    }
}