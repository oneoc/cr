<?php
// 本类由系统自动生成，仅供测试用途
class FriendRequestViewModel extends ViewModel {
    // 回调方法 初始化模型
    protected function _initialize() {
    }
    //字段验证
    protected $_validate = array(
    );
    //字段"for"不能使用?!!
    public $viewFields = array(
        'FriendRequest'=>array("id","for"=>"_for"),
        'User'=>array('name'=>'who_name', '_on'=>'FriendRequest.who=User.id'),
       );
    
}