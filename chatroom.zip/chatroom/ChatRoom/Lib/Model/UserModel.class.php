<?php
// 本类由系统自动生成，仅供测试用途
class UserModel extends CommonModel {
    const MESSAGE_TYPE_SEND=1;
    const MESSAGE_TYPE_RECV=2;
    
    const REQUEST_STATUS_REQUESTING=1;
    const REQUEST_STATUS_IGNORED=2;
    const REQUEST_STATUS_REFUSED=3;
    const REQUEST_STATUS_AGREED=4;
    protected $tableName        =   'User';
    // 回调方法 初始化模型
    protected function _initialize() {
    }
    //字段验证
    protected $_validate = array(
        array('name','','帐号名称已经存在！',0,'unique',1),      // 在新增的时候验证name字段是否唯一
        //array('mail','','邮箱已经存在！',0,'unique',1)           // 在新增的时候验证mail字段是否唯一
    );
    /**
     * 同意,拒绝,忽略动作代码
     */
    const ACTION_AGREE=2;
    const ACTION_REFUSE=3;
    const ACTION_IGNORE=4;
    /**
     * 系统管理员用户
     * @return ManagerModel
     */
    public function get_manager()
    {
        $m=D("Manager");
        if($m->find(array("type"=>UserType::MANAGER)))return $m;
    }
    /**
     * 获取用户类型的封装
     * @return UserType
     */
    function get_user_type()
    {
        return new UserType(isset($this->data["type"])?$this->data["type"]:0);
    }
    /**
     * 添加用户
     * @return boolean
     */
    function add_user($_name,$_psw,$_mail,$_type=UserType::USER,$_id=-1)
    {
        $u=null;
        $this->data=array("name"=>$_name,"password"=>$_psw,"mail"=>$_mail,"type"=>$_type);
        if($_id!=-1)$this->data["id"]=$_id;
        if($this->create($this->data))
        {
            $id=$this->add();
            $u=$this->get_user($_name);
            //用户插入成功,则将用户加入全局聊天室
            $r=D("Room")->get_room("默认聊天室");
            if($r==null){
                $r=D("Room")->add_room("默认聊天室",1);
            }
            if($r!=null){
                if($r->add_user($u->id,$u->type==UserType::MANAGER?true:false)!=false)return true;
            }
        }
        return $u;
    }
    /**
     * 由姓名获取用户
     * @return null|UserModel|ManagerModel
     */
    function get_user($_name){
        $u=D("User")->where(array("name"=>$_name))->select();
        if(count($u)==0)return null;
        $user=D("User");
        if($u[0]["type"]==UserType::MANAGER)$user=D("Manager");
        $user->find($u[0]["id"]);
        return $user;
    }
    /**
     * 检查密码
     * @param 用户输入密码
     * @return boolean
     */
    function check_password($_psw)
    {
        if($this->password==$_psw)return true;
        return false;
    }
    /**
     * 添加朋友
     * @param 朋友id
     * @return boolean
     */
    function add_friend($_friend){
        if($this->has_friend($_friend))return;
        D("Friend")->add(array("user"=>$this->id,"friend"=>$_friend));
    }
    /**
     * 删除朋友
     * @param 朋友姓名
     * @return boolean
     */
    function delete_friend($_me,$_friend){
        D("Friend")->where(array("user"=>$_me,"friend"=>$_friend))->delete();
    }
    /**
     * 加入房间
     * @param 房间名
     * @return boolean
     */
    function add_to_room($_room)
    {
    }
    /**
     * 退出房间
     * @param 房间名
     * @return boolean
     */
    function exit_from_room($_room)
    {
    }
    /**
     * 请求加好友
     * @param 朋友姓名
     * @return boolean
     */
    function request_friend($_friend){
        if($this->has_friend($_friend))return;
        if(D("FriendRequest")->where(array("who"=>$this->id,"for"=>$_friend))->select()==false){
            D("FriendRequest")->add(array("who"=>$this->id,"for"=>$_friend,"status"=>UserModel::REQUEST_STATUS_REQUESTING));
        }
    }
    /**
     * 好友请求状态
     * @param 好友姓名,为空时返回所有发出好友请求的用户
     * @return boolean
     */
    function request_friends_status($_friend=""){
    }
     /**
     * 请求加入房间
     * @param 房间名
     * @return boolean
     */
    function request_room($_room){
        if(D("RoomRequest")->where(array("who"=>$this->id,"for"=>$_room))->select()==false && !$this->is_in_room($_room)){
            D("RoomRequest")->add(array("who"=>$this->id,"for"=>$_room,"status"=>UserModel::REQUEST_STATUS_REQUESTING));
        }
    }
     /**
     * 查询所有朋友
     * @return array
     */
    function get_friends()
    {
    }
     /**
     * 查询所有房间
     * @return array
     */
    function get_rooms()
    {
    }
     /**
     * 检查是否已经登录
     * @return boolean
     */
    function is_login(){
        $logins=$this->get_login_users();
        foreach($logins as $l){
            if($l==$this->data["id"])return true;
        }
        return false;
    }
     /**
     * 登录
     * @param 用户登录密码
     * @return boolean
     */
    function login($_psw){
        if($this->password!=$_psw)return false;
        $logins=$this->get_login_users();
        $logins[]=$this->data["id"];
        $logins=array_unique($logins);
        $logins=array_values($logins);
        $this->set_login_users($logins);
        return true;
    }
     /**
     * 退出登录
     * @return boolean
     */
    function quit(){
        $logins=$this->get_login_users();
        $i=array_search($this->data["id"],$logins);
        if($i===false) return;
        unset($logins[$i]);
        $logins=array_values($logins);
        $this->set_login_users($logins);
        return true;
    }
    /**
     * 返回所有登录的用户
     */
    private function get_login_users(){
        if(isset($_COOKIE["logins"])) $logins=wf_http_parse_cookie($_COOKIE["logins"]);
        else $logins=array();
        return $logins;
    }
    /**
     * 设置登录用户
     */
    private function set_login_users($_logins){
        setcookie("logins",wf_http_build_cookie($_logins),0,"/");
    }
     /**
     * 检查用户是否有权限
     * @param string 权限action 
     * @param AccessControl 访问控制列表
     * @return boolean
     */
    function has_priority($_priority,$_access_control)
    {
        return $_access_control->check_priority($this->type,$_priority);
    }
    /**
     * 处理显示用户列表操作按钮
     * @param array 用户数据列表
     * @return array　处理后的用户数据表
     */
    function show_button_user()
    {
        
    }
    private function show_button_friend_delete_or_request(){}
    private function show_button_user_delete(){}
    private function show_button_private_chat(){}
    /**
     * 处理显示房间列表操作按钮
     * @param array 房间数据列表
     * @return array　处理后的房间数据表
     */
    function show_button_room(){}
    private function show_button_room_delete(){}
    private function show_button_room_request_or_exit(){}
    private function show_buton_room_enter(){}
    /**
     * 用户是否管理员
     * @return boolean
     */
    function is_manager(){
        if($this->type==UserType::MANAGER)return true;
        return false;
    }
    /**
     * 是否有朋友
     * @param string 要检查的朋友
     * @return boolean
     */
    function has_friend($_friend){
        if(D("Friend")->where(array("user"=>$this->id,"friend"=>$_friend))->select()==false)return false;
        return true;
    }
    /**
     * 左侧菜单
     */
    function show_button_left_menu(){}
    /**
     * 是否在房间
     * @param string 房间
     * @return boolean
     */
    function is_in_room($_room){
        if(D("RoomUser")->where(array("user"=>$this->id,"room"=>$_room))->select()==false)return false;
        return true;
    }
    /**
     * 是否存在指定用户
     * @param string 用户
     * @return boolean
     */
    function is_exist(){}
    /**
     * 返回与指定好友指定时间之后的私聊信息
     * @param string 朋友
     * @param datetime 时间
     * @return array
     */
    function get_messages_since($_friend,$_time){
        $w=array("me"=>$this->id,"friend"=>$_friend["id"]);
        $m=D("FriendMessageView")->where($w)->order("time asc");
        $map=array();
        if(trim($_time)!=""){
            $map["time"]=array("gt",$_time);
            $data =$m->where($map)->select();
        }else 
            $data=$m->select();
        if($data==false)$data=array();
        return $data;
    }
    /**
     * 给好友发送信息
     * @param string 朋友
     * @param message 消息
     * @return boolean
     */
    function send_message_friend($_friend,$_message,$_d=false){
        if(is_string($_message))$_message=array($_message);
        if(!is_array($_message))return;
        $d=date("Y-n-d H:i:s");
        if($_d!==false)$d=$_d;
        foreach($_message as $m){
            //dump($_friend["id"]);
            //dump($this);
            D("FriendMessage")->add(array("friend"=>$_friend["id"],"me"=>$this->id,"time"=>$d,'message'=>$m,'type'=>UserModel::MESSAGE_TYPE_SEND));
            D("FriendMessage")->add(array("friend"=>$this->id,"me"=>$_friend["id"],"time"=>$d,'message'=>$m,'type'=>UserModel::MESSAGE_TYPE_RECV));
        }
    }
    /**
     * 给房间发送信息
     * @param string 房间
     * @param message 消息
     * @return boolean
     */
    function send_message_room($_room,$_message,$_d=false){
        if(is_string($_message))$_message=array($_message);
        if(!is_array($_message))return;
        $d=date("Y-n-d H:i:s");
        if($_d!==false)$d=$_d;
        foreach($_message as $m){
            D("RoomMessage")->add(array("room"=>$_room->id,"user"=>$this->id,"time"=>$d,'message'=>$m));
        }
    }
    /**
     * 返回与指定好友最近的指定数目的私聊信息
     * @param int 朋友
     * @param datetime 时间
     * @return array
     */
    function get_messages_latest($_friend,$_count=0){
        $w=array("me"=>$this->id,"friend"=>$_friend);
        $m=D("FriendMessageView")->where($w)->order("time desc");
        if($_count!=0)$data=$m->limit(0,$_count)->select();
        else $data=$m->select();
        if($data==false)$data=array();
        return array_reverse($data);
    }
    function get_messages_latest_room($_room,$_count=0){
        $data=$_room->get_messages_latest($_count);
        foreach($data as $i=>$d){
            if($d["user"]==$this->id)$data[$i]['type']=UserModel::MESSAGE_TYPE_SEND;
            else $data[$i]['type']=UserModel::MESSAGE_TYPE_RECV;
        }
        return $data;
    }
    function get_messages_since_room($_room,$time=""){
        $data=$_room->get_messages_since($time);
        foreach($data as $i=>$d){
            if($d["user"]==$this->id)$data[$i]['type']=UserModel::MESSAGE_TYPE_SEND;
            else $data[$i]['type']=UserModel::MESSAGE_TYPE_RECV;
        }
        return $data;
    }
    
    /**
     * 处理好友请求
     * @param int 请求id
     * @param int 动作代码
     * @return boolean
     */
    function friend_request_process($_id,$_action){
        $d=D("FriendRequest")->find($_id);
        if($d==false)return;
        D("FriendRequest")->delete($_id);
        if($_action==UserModel::ACTION_AGREE){
            $u=D("User");
            $u->find($d["who"]);
            $u->add_friend($d["for"]);
            $u->find($d["for"]);
            $u->add_friend($d["who"]);
        }
    }
    /**
     * 获取指定房间
     * @param string 房间
     * @return RoomModel
     */
    function get_room($_room){}
    /**
     * 获取所有用户
     * @return array
     */
    function get_all_users(){}
    /**
     * 获取用户信息用于显示
     * @return array
     */
    function get_show_user_info($_title="用户详细信息"){
        $ret=array(
            "middle"=>array(
                "head"=>$_title,
            ),
        );
        $middle=&$ret["middle"];
        $middle["list"]=array(
            array("name"=>"姓名","value"=>$this->data["name"]),
            array("name"=>"邮箱","value"=>$this->data["mail"]),
        );
        return $ret;
    }
    /**
     * 获取所有用户用于显示
     * @return array
     */
    function get_show_all_users($_title="所有用户"){
        
        $ret=array(
            "middle"=>array(
                "operations"=>array(
                    "user_delete"=>array("text"=>"删除用户","url"=>"Manager/user_delete"),
                    "friend_request"=>array("text"=>"请求好友","url"=>"User/friend_request"),
                    "friend_delete"=>array("text"=>"删除好友","url"=>"User/friend_delete"),
                    "friend_chat"=>array("text"=>"与他聊天","url"=>"User/friend_chat"),
                ),
                "head"=>$_title,
                "list"=>array()
            ),
        );
        $middle=&$ret["middle"];
        $list=&$ret["middle"]["list"];
        //排序,先好友,然后其他按序号
        $data=$this->order("id asc")->where("id <>".$this->id)->select();
        $friends=D("Friend")->field("friend")->where(array("user"=>$this->id))->select();
        if($friends==false)$friends=array();
        $temp=array();
        foreach($friends as $f){
            $temp[]=$f["friend"];
        }
        $friends=$temp;
        if($data==false)$data=array();
        $s=0;
        $e=$_e=sizeof($data)-1;
        while($s<=$e){
            $operations=array();
            if($this->is_manager())$operations[]="user_delete";
            if(array_search($data[$s]["id"],$friends,true)!==false & $s<=$_e){
                //好友
                $operations=array_merge($operations,array("friend_delete","friend_chat"));
                $list[]=array("id"=>$data[$s]["id"],"name"=>$data[$s]["name"],"mail"=>$data[$s]["mail"],"operations"=>$operations);
            }else if($s>$_e){
                //非好友
                $operations=array_merge($operations,array("friend_request"));
                $list[]=array("id"=>$data[$s]["id"],"name"=>$data[$s]["name"],"mail"=>$data[$s]["mail"],"operations"=>$operations);
            }else{
                $data[++$e]=$data[$s];
            }
            $s++;
        }
        return $ret;
    }
    /**
     * 获取所有房间用于显示
     * @return array
     */
    function get_show_all_rooms($_title="所有房间"){
        $ret=array(
            "middle"=>array(
                "operations"=>array(
                    "room_delete"=>array("text"=>"删除房间","url"=>"Manager/room_delete"),
                    "room_request"=>array("text"=>"请求加入","url"=>"User/room_request"),
                    "room_exit"=>array("text"=>"退出房间","url"=>"User/room_exit"),
                    "room_chat"=>array("text"=>"进入聊天","url"=>"User/room_chat"),
                ),
                "head"=>$_title,
                "list"=>array()
            ),
        );
        $middle=&$ret["middle"];
        $list=&$ret["middle"]["list"];
        //排序,先好友,然后其他按序号
        $data=D("Room")->order("id asc")->select();
        $myrooms=D("RoomUser")->field("room")->where(array("user"=>$this->id))->select();
        if($myrooms==false)$myrooms=array();
        if($data==false)$data=array();
        $temp=array();
        foreach($myrooms as $r){
            $temp[]=$r["room"];
        }
        $myrooms=$temp;
        $s=0;
        $e=$_e=sizeof($data)-1;
        while($s<=$e){
            $operations=array();
            if($this->is_manager())$operations[]="room_delete";
            if(array_search($data[$s]["id"],$myrooms,true)!==false & $s<=$_e){
                //我的房间
                $operations=array_merge($operations,array("room_exit","room_chat"));
                $list[]=array("id"=>$data[$s]["id"],"name"=>$data[$s]["name"],"operations"=>$operations);
            }else if($s>$_e){
                //
                $operations=array_merge($operations,array("room_request"));
                $list[]=array("id"=>$data[$s]["id"],"name"=>$data[$s]["name"],"operations"=>$operations);
            }else{
                $data[++$e]=$data[$s];
            }
            $s++;
        }
        return $ret;
    }
    /**
     * 获取所有好友请求用于显示
     * @return array
     */
    function get_show_friends_request($_title="待处理的好友请求"){
        $ret=array(
            "middle"=>array(
                "operations"=>array(
                    "friend_request_ignore"=>array("text"=>"忽略","url"=>"User/friend_request_process","params"=>array("act"=>UserModel::ACTION_IGNORE)),
                    "friend_request_refuse"=>array("text"=>"拒绝","url"=>"User/friend_request_process","params"=>array("act"=>UserModel::ACTION_REFUSE)),
                    "friend_request_agree"=>array("text"=>"同意","url"=>"User/friend_request_process","params"=>array("act"=>UserModel::ACTION_AGREE)),
                ),
                "head"=>$_title,
                "list"=>array()
            ),
        );
        $middle=&$ret["middle"];
        $list=&$ret["middle"]["list"];
        //
        $data=D("FriendRequestView")->where(array("_for"=>$this->id))->order("id asc")->select();
        if($data==false)$data=array();
        $operations=array("friend_request_ignore","friend_request_refuse","friend_request_agree");
        foreach($data as $d){
            $list[]=array("id"=>$d["id"],"who_name"=>$d["who_name"],"operations"=>$operations);
        }
        return $ret;
    }
    /**
     * 获取所有房间请求用于显示
     * @return array
     */
    function get_show_rooms_request($_title="待处理的房间加入请求"){
        $ret=array(
            "middle"=>array(
                "operations"=>array(
                    "room_request_ignore"=>array("text"=>"忽略","url"=>"Manager/room_request_process","params"=>array("act"=>UserModel::ACTION_IGNORE)),
                    "room_request_refuse"=>array("text"=>"拒绝","url"=>"Manager/room_request_process","params"=>array("act"=>UserModel::ACTION_REFUSE)),
                    "room_request_agree"=>array("text"=>"同意","url"=>"Manager/room_request_process","params"=>array("act"=>UserModel::ACTION_AGREE)),
                ),
                "head"=>$_title,
                "list"=>array()
            ),
        );
        $middle=&$ret["middle"];
        $list=&$ret["middle"]["list"];
        //
        $data=D("RoomRequestView")->order("id asc")->select();
        if($data==false)$data=array();
        $operations=array("room_request_ignore","room_request_refuse","room_request_agree");
        foreach($data as $d){
            $list[]=array("id"=>$d["id"],"who_name"=>$d["who_name"],"room_name"=>$d["room_name"],"operations"=>$operations);
        }
        return $ret;
    }
    /**
     * 获取所有私聊用于显示
     * @return array
     */
    function get_show_friend_chat($id,$_title="朋友"){
        $ret=array(
            "message_list"=>__ROOT__."/ChatRoom/index.php/User/messages_list_friend/u/".$this->id."/f/".$id,
            "message_send"=>array("url"=>"User/message_friend","params"=>array("f"=>$id)),
            "middle"=>array(
                "head"=>$_title,
                "list"=>array()
            ),
            "right"=>array(
                "head"=>"",
                "list"=>array()
            ),
        );
        $middle=&$ret["middle"];
        $middle_list=&$ret["middle"]["list"];
        
        //$f=D("User")->find();
        $data=$this->get_messages_latest($id,100);
        if(sizeof($data)==0)$ret["message_send"]["params"]["latest"]="";
        else $ret["message_send"]["params"]["latest"]=$data[sizeof($data)-1]["time"];
        foreach($data as $d){
            $middle_list[]=array("send_clear"=>$d["type"]==UserModel::MESSAGE_TYPE_SEND?"<div class='clear'></div>":"","receive_or_send"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?"receive":"send","name"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?$d["user_name"]:"我","time"=>$d["time"],"message"=>$d["message"]);
        }
        
        $right=&$ret["right"];
        $right_list=&$ret["right"]["list"];
        
        $data=D("User")->find($id);
        $right["head"]="朋友资料";
        $right_list[]=array("name"=>"姓名","value"=>$data["name"]);
        $right_list[]=array("name"=>"邮箱","value"=>$data["mail"]);
        return $ret; 
    }
    /**
     * 获取所有群聊用于显示
     * @return array
     */
    function get_show_room_chat($id,$_title="聊天室"){
        $ret=array(
            "message_list"=>__ROOT__."/ChatRoom/index.php/User/messages_list_room/u/".$this->id."/r/".$id,
            "message_send"=>array("url"=>"User/message_room","params"=>array("r"=>$id,)),
            "middle"=>array(
                "head"=>$_title,
                "list"=>array()
            ),
            "right"=>array(
                "operations"=>array(
                    "member_delete"=>array("text"=>"踢出","url"=>"Manager/member_delete","params"=>array("r"=>$id)),
                ),
                "head"=>"",
                "list"=>array()
            ),
        );
        $r=D("Room");
        $r->find($id);
        $middle=&$ret["middle"];
        $middle_list=&$ret["middle"]["list"];
        
        $data=$this->get_messages_latest_room($r,100);
        if(sizeof($data)==0)$ret["message_send"]["params"]["latest"]="";
        else $ret["message_send"]["params"]["latest"]=$data[sizeof($data)-1]["time"];
        foreach($data as $d){
            $middle_list[]=array("send_clear"=>$d["type"]==UserModel::MESSAGE_TYPE_SEND?"<div class='clear'></div>":"","receive_or_send"=>$d["type"]==UserModel::MESSAGE_TYPE_RECV?"receive":"send","name"=>$d["user_name"],"time"=>$d["time"],"message"=>$d["message"]);
        }
        
        $right=&$ret["right"];
        $right_list=&$ret["right"]["list"];
        
        $r=D("Room");
        $data=$r->get_all_users();
        $right["head"]="成员(".sizeof($data).")";
        $operations=array();
        if($this->is_manager())$operations[]="member_delete";
        foreach($data as $d){
            $right_list[]=array("id"=>$d["id"],"name"=>$d["user_name"],"operations"=>$operations);
        }
        return $ret;         
    }
}