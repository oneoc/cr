<?php
// 本类由系统自动生成，仅供测试用途
class ManagerModel extends UserModel {
    /**
     * 重置系统
     * 清空所有表,只保留管理员用户及全局聊天室
     */
    function system_reset($u){
        $db=new Database();
        $u=D("User")->find($u);
        if($db->execute_clean()){
            if($this->add_user($u["name"],$u["password"],$u["mail"],$u["type"],$u["id"])!==false){
                return true;
            }
        }
        return false;
    }
    /**
     * 删除用户
     * @param 用户
     * @return boolean
     */
    function user_delete($_user){
        $this->delete($_user);
    }
    /**
     * 返回所有房间请求
     * @return array
     */

}