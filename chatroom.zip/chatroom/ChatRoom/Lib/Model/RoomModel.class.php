<?php
// 本类由系统自动生成，仅供测试用途
class RoomModel extends CommonModel {
    // 回调方法 初始化模型
    protected function _initialize() {
    }
    //字段验证
    protected $_validate = array(
        array('name','','帐号名称已经存在！',0,'unique',1),      // 在新增的时候验证name字段是否唯一
    );
    /**
     * 添加房间
     * @param string 房间名
     * @return　RoomModel
     */
    public function add_room($_name,$_id=-1){
        //房间名必须唯一
        $r=null;
        $data=array("name"=>$_name);
        if($_id!=-1)$data["id"]=$_id;
        if($this->create($data))
        {
            $id=$this->add($data);
            if($_id!=-1)$id=$_id;
            if($id!==false)
            {
                $r=D("Room");
                $r->find($id);
            }
            $r->add_user(D("User")->get_manager()->id,true);
        }
        return $r;
    }
    /**
     * 由名字获取房间
     * @param string 房间名
     * @return　RoomModel
     */
    public function get_room($_name){
        $r=D("Room")->where(array("name"=>$_name))->select();
        if(count($r)==0)return null;
        $ret=D("Room");
        $ret->find($r[0]["id"]);
        return $ret;
    }
    /**
     * 删除房间
     * @param 房间id
     * @return boolean
     */
    public function delete_room($_id=-1){
        if($_id==-1){
            $_id=$this->data["id"];
        }
        $ret=$this->find($_id);
        if($ret===false)return false;
        if($ret===null)return true;
        $this->delete($_id);
        return true;
    }
    /**
     * 向房间添加用户
     * @param 用户
     * @param 是否管理员
     * @return boolean
     */
    public function add_user($_user,$_is_manager=false){
        if(D("Room")->find($this->data["id"])==false || D("User")->find($_user)==false)return false;
        if(D("RoomUser")->where(array("room"=>$this->data["id"],"user"=>$_user))->find()!=false)return true;
        $is_manager=$_is_manager?1:0;
        D("RoomUser")->add(array("room"=>$this->data["id"],"user"=>$_user,"is_manager"=>$is_manager));
        return true;
    }
    /**
     * 把用户踢出房间
     * @param 房间
     * @param 用户
     * @return boolean
     */
    public function delete_user($_user){
        D("RoomUser")->where(array("room"=>$this->data["id"],"user"=>$_user))->delete();
        return true;
    }
    /**
     * 得到指定房间所有用户
     * @param 房间
     * @return
     */
    public function get_all_users($_room){
        $d=D("RoomUserView")->where(array("room"=>$this->id))->select();
        if($d==false)return array();
        return $d;
    }
    /**
     * 决断房间是否有用户
     * @param 房间
     * @param 要查询的用户
     * @return
     */
    public function has_user($_room,$_user){
        
    }
    /**
     * 得到房间在指定时间之后的信息
     * @param 房间
     * @param 时间
     * @return
     */
    public function get_messages_since($_time){
        $w=array("room"=>$this->id);
        $m=D("RoomMessageView")->where($w)->order("time asc");
        $map=array();
        if(trim($_time)!=""){
            $map["time"]=array("gt",$_time);
            $data =$m->where($map)->select();
        }else 
            $data=$m->select();
        if($data==false)$data=array();
        return $data;
    }
    /**
     * 得到房间最近的信息
     * @param 房间
     * @param 消息数,为0读取全部消息
     * @return
     */
    public function get_messages_latest($_count=0){
        $w=array("room"=>$this->id);
        $m=D("RoomMessageView")->where($w)->order("time desc");
        if($_count!=0)$data=$m->limit(0,$count)->select();
        else $data=$m->select();
        if($data==false)$data=array();
        return array_reverse($data);
    }
    /**
     * 得到所有房间
     * @return
     */
    public function get_all_rooms(){
        
    }
    function request_rooms_status(){}
    /**
     * 房间请求处理
     * @param 请求id
     * @param 处理的动作
     * @return boolean
     */
    function room_request_process($_id,$_action){
        $d=D("RoomRequest")->find($_id);
        if($d==false)return;
        D("RoomRequest")->delete($_id);
        if($_action==UserModel::ACTION_AGREE){
            $r=D("Room");
            $r->find($d["for"]);
            $r->add_user($d["who"]);
        }
    }
    /**
     * 删除房间
     * @param 房间
     * @return boolean
     */
    function room_delete($_room){}
}