<?php
// 本类由系统自动生成，仅供测试用途
class FriendMessageViewModel extends ViewModel {
    // 回调方法 初始化模型
    protected function _initialize() {
    }
    //字段验证
    protected $_validate = array(
    );
    //
    public $viewFields = array(
         'FriendMessage'=>array('id','me','friend','time','message','type'),
         'User'=>array('name'=>'user_name', '_on'=>'FriendMessage.friend=User.id'),
       );
    
}