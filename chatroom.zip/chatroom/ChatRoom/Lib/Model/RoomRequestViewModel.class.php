<?php
// 本类由系统自动生成，仅供测试用途
class RoomRequestViewModel extends ViewModel {
    // 回调方法 初始化模型
    protected function _initialize() {
    }
    //字段验证
    protected $_validate = array(
    );
    //
    public $viewFields = array(
         'RoomRequest'=>array('id'),
         'User'=>array('name'=>'who_name', '_on'=>'RoomRequest.who=User.id'),
         'Room'=>array('name'=>'room_name', '_on'=>'RoomRequest.for=Room.id'),
       );
    
}