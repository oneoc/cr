<?php
// 本类由系统自动生成，仅供测试用途
class AccessControl{
    /**
     * 用户类型否定权限
     */
    private $no_priority=array();
    /**
     * 添加用户否定权限
     * @param int 用户类型
     * @param array 要否定的权限
     * @return void
     */
    public function add_no_priority($_userType,$_prioritys)
    {
        if(!isset($this->no_priority[$_userType]))$this->no_priority[$_userType]=array();
        $this->no_priority[$_userType]=array_unique(array_merge($this->no_priority[$_userType],$_prioritys));
    }
    /**
     * 判断用户是否有权限
     * @param int用户类型
     * @param string要检查的权限
     * @return boolean
     */
    public function check_priority($_userType,$_priority)
    {
        return true;
        //if($_priority==false)return true;
        //if(!isset($this->no_priority[$_userType]))return true;
        //return !in_array($_priority,$this->no_priority[$_userType],true);
    }
}