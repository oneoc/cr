<?php
// 本类由系统自动生成，仅供测试用途
class UserType{
    /**
     * 管理员,常量
     */
    const MANAGER=1;
    /**
     * 用户,常量
     */
    const USER=2;
    /**
     * 当前
     */
    private $userType=0;
    public function __construct($_userType) {
        $this->userType=$_userType;
    }
    /**
     * 是否管理员
     * @return boolean
     */
    public function is_manager()
    {
        return $this->userType==$this->MANAGER?true:false;
    }
    /**
     * 获取当前类型代码
     * @return int
     */
    public function get_type_code()
    {
        return $this->userType;
    }
    /**
     * 设置为管理员
     * @return void
     */
    public function set_manager()
    {
        $this->userType=$this->MANAGER;
    }
    /**
     * 设置为管理员
     * @return void
     */
    public function set_user()
    {
        $this->userType=$this->USER;
    }
}