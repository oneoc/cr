<?php
// 本类由系统自动生成，仅供测试用途
class Database{

    private $init_sql="
CREATE TABLE `user` (

`id` int(255) UNSIGNED NOT NULL AUTO_INCREMENT,

`name` varchar(255) NOT NULL,

`password` varchar(255) NOT NULL,

`mail` varchar(255) NOT NULL,

`type` int NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `room` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`name` varchar(255) NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `friend` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`user` int UNSIGNED NOT NULL,

`friend` int UNSIGNED NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `room_user` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`room` int UNSIGNED NOT NULL,

`user` int UNSIGNED NOT NULL,

`is_manager` tinyint(1) NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `friend_request` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`who` int UNSIGNED NOT NULL,

`for` int UNSIGNED NOT NULL,

`status` tinyint NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `room_request` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`who` int UNSIGNED NOT NULL,

`for` int UNSIGNED NOT NULL,

`status` tinyint NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `room_message` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`room` int UNSIGNED NOT NULL,

`user` int UNSIGNED NOT NULL,

`time` datetime NOT NULL,

`message` varchar(255) NOT NULL,

PRIMARY KEY (`id`) 

);



CREATE TABLE `friend_message` (

`id` int UNSIGNED NOT NULL AUTO_INCREMENT,

`friend` int UNSIGNED NOT NULL,

`me` int UNSIGNED NOT NULL,

`time` datetime NOT NULL,

`message` varchar(255) NOT NULL,
`type` tinyint NOT NULL,

PRIMARY KEY (`id`) 

);





ALTER TABLE `friend` ADD CONSTRAINT `slave` FOREIGN KEY (`friend`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `friend` ADD CONSTRAINT `master` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_user` ADD CONSTRAINT `room` FOREIGN KEY (`room`) REFERENCES `room` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_user` ADD CONSTRAINT `user` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `friend_request` ADD CONSTRAINT `who-request-friend` FOREIGN KEY (`who`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `friend_request` ADD CONSTRAINT `for-who-friend` FOREIGN KEY (`for`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_request` ADD CONSTRAINT `who-request-room` FOREIGN KEY (`who`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_request` ADD CONSTRAINT `for-which-room` FOREIGN KEY (`for`) REFERENCES `room` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_message` ADD CONSTRAINT `belong-which-room` FOREIGN KEY (`room`) REFERENCES `room` (`id`) ON DELETE CASCADE;

ALTER TABLE `room_message` ADD CONSTRAINT `who-send` FOREIGN KEY (`user`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `friend_message` ADD CONSTRAINT `me` FOREIGN KEY (`me`) REFERENCES `user` (`id`) ON DELETE CASCADE;

ALTER TABLE `friend_message` ADD CONSTRAINT `friend` FOREIGN KEY (`friend`) REFERENCES `user` (`id`) ON DELETE CASCADE
";
    private $clear_sql="
delete from `room`;
delete from `user`;
delete from `friend_message`;
delete from `room_message`;
delete from `friend_request`;
delete from `room_request`;
delete from `room_user`;
delete from `friend`
";
    /**
     * 创建表
     * @return boolean
     */
    public function  execute_init(){
        $sql=explode(";",$this->init_sql);
        $ret=$this->execute_sql($sql);
        return $ret;

    }/**
     * 清空所有表
     * @return boolean
     */
    public function execute_clean()
    {
        $sql=explode(";",$this->clear_sql);
        $ret=$this->execute_sql($sql);
        return $ret;
    }
    /**
     * 是否已经初始化
     * @return boolean
     */
    public function  isInitialized(){
        $ret=false;
        $res=mysql_connect(C('DB_HOST'),C('DB_USER'),C('DB_PWD'));
        if($res){
            if(mysql_select_db (C('DB_NAME'),$res)){
                $sql="SELECT * FROM `user`";
                if(mysql_query($sql)!==false)$ret= true;
            }
            mysql_close($res);
        }
        return $ret;
        /*
        if(!!M("User")->select()==false)return false;
        return true;
        */
    }
    
    private function execute_sql($sql)
    {
        foreach($sql as $s){
            if(M()->execute($s)===false)return false;
        }
        return true;
    }
    /**
     * 检查数据库连通信,并配置数据库
     * @param 主机
     * @param 数据库
     * @param 用户
     * @param 密码
     */
    public static function config($DB_HOST,$DB_NAME,$DB_USER,$DB_PWD){
        file_put_contents(APP_PATH."Public/config/conf.php",$config_data);
        $res=mysql_connect($DB_HOST,$DB_USER,$DB_PWD);
        if($res){
            if(mysql_select_db ($DB_NAME,$res)){
                mysql_close($res);
                $config_data="<?php\nreturn array(\n\t'DB_HOST'=>'".$DB_HOST."',\n\t'DB_NAME'=>'".$DB_NAME."',\n\t'DB_USER'=>'".$DB_USER."',\n\t'DB_PWD'=>'".$DB_PWD."'\n);\n?>";
                if(file_put_contents(APP_PATH."Public/config/conf.php",$config_data)!==false){
                    Database::load_config();
                    return true;
                }
                return "安装时写配置文件出错!";
            }
            return "不能创建指定的数据库!";  
        }
        return "不能连接到指定数据库,用户名或者密码错误!";  
    }
    /**
     * 加载数据库配置
     */
    public static function load_config(){
        if(is_file(APP_PATH."Public/config/conf.php"))
            C(include APP_PATH."Public/config/conf.php");
    }
    
}