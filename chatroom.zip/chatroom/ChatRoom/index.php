﻿<?php
//定义项目名称和路径
define('APP_NAME', 'ChatRoom');
define('APP_PATH', './');
//对于检测不到正确目录的服务器
//define("_PHP_FILE_","/ChatRoom/index.php");
//define('__ROOT__',"");
// 加载框架入口文件
//define('APP_DEBUG', true);
require( "../ThinkPHP/ThinkPHP.php");