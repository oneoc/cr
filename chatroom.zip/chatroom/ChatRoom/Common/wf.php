<?php

/**
 * @author blog.anchen8.net
 * @copyright 2014
 */
    function wf_http_build_cookie($_cookie_array){
        $temp="";
        foreach($_cookie_array as $c)
        {
            $temp=$temp.";".$c;
        }
        $temp=substr($temp,1,strlen($temp)-1);
        return base64_encode($temp);
    }
    function wf_http_parse_cookie($_cookie_string){
        return explode(";",base64_decode($_cookie_string));
    }


?>