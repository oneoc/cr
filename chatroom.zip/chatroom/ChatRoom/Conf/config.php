<?php
return array(
	//'配置项'=>'配置值'
    'DB_TYPE'               => 'mysql',     // 数据库类型
    'DB_HOST'               => 'localhost', // 服务器地址
    'DB_NAME'               => 'chatroom',          // 数据库名
    'DB_USER'               => 'wangfei',      // 用户名
    'DB_PWD'                => 'wangfei',          // 密码
    'DB_PORT'               => '',        // 端口
    'DB_PREFIX'             => '',    // 数据库表前缀
    'SHOW_PAGE_TRACE'       => true,
    'DB_CHARSET'            =>'utf8',// 数据库编码默认采用utf8
    
    'DEFAULT_CHARSET'       => 'utf-8',
    'URL_MODEL'             => '0',
    "LOAD_EXT_FILE"=>"wf",             //加载扩展文件，在Common目录中。
    'APP_AUTOLOAD_PATH' =>'@.WFClass', //自动加载类搜索路径
    'SHOW_PAGE_TRACE'   =>false,
);
?>