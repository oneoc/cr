<?php
return array(
	'DB_HOST'=>'fdb7.biz.nf',
	'DB_NAME'=>'1589150_data',
	'DB_USER'=>'1589150_data',
	'DB_PWD'=>'wangfei0314'
);
?>