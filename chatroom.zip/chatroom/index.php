<?php

/**
 * @author blog.anchen8.net
 * @copyright 2014
 */
header("location: ChatRoom/");
exit;


?>